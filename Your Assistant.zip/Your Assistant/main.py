import pyttsx3
import speech_recognition as sr
import os
import webbrowser
import openai
import datetime
import random
def say(text):
    engine = pyttsx3.init()
    voices=engine.getProperty('voices')
    engine.setProperty('voice',voices[1].id)
    engine.say(text)
    engine.runAndWait()

def take_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        r.pause_threshold = 0.5
        audio = r.listen(source)
        try:
            query = r.recognize_google(audio, language="en-IN")
            return query
        except sr.UnknownValueError:
            return None

def ai(prompt):
    openai.api_key = "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"
    text=f"OpenAi response for prompt: {prompt} \n ********************** \n\n"
    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=prompt,
        temperature=1,
        max_tokens=256,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )
    #print(response["choices"][0]["text"])
    text += response["choices"][0]["text"]
    if not os.path.exists('Openai'):
        os.mkdir("Openai")

    with open(f"Openai/prompt-{random.randint(1, 23434356)}", 'w') as f:
        f.write(text)


if __name__ == '__main__':
    asleep = False
    greetings = "Hello, I am Bhreetto"
    apps = {
        "whatsapp": r"C:\Users\HP\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Chrome Apps\WhatsApp.lnk",
    }
    i=0
    print(greetings)
    say(greetings)
    while True:
        while not asleep:
            print("Listening...")
            query = take_command()
            print(f"User said: {query}")
            if query is None:
                print("No voice response.")
                continue
            words = query.lower().split()
            if query.lower()=="go to sleep" or query.lower()== "sleep my assistant":
                    asleep = True
                    print("Going to sleep")
                    say("Going to sleep")

            elif query.lower() == "awake" or query.lower() == "wake up":
                say("Already awake")
                print("Already awake")

            elif "the time" in query.lower():
                time = datetime.datetime.now().strftime("%H:%M:%S")
                print(f"Now the time is {time}")
                say(f"Now the time is {time}")

            elif 'open' in words and len(words) != words.index('open') + 1 and words[words.index('open') + 1] in apps:
                for app, location in apps.items():
                    say(f"Opening {app}...")
                    os.system(f'start "" "{location}"')
                    break
            elif 'search' in words and len(words) != words.index('search') + 1:
                search_index = words.index('search') + 1
                say(f"Searching {words[search_index]}...")
                webbrowser.open(f"https://www.{words[search_index]}.com")
            elif "using ai" in query.lower():
                ai(prompt=query)

            elif query.lower() == "who are you":
                print(
                    "I am Bhreetto, I am a personal voice assistant.\n I can do several task like telling the time, searching web pages, openning apps and I can answer your questions.")
                say("I am Bhreetto, I am a personal voice assistant.\n I can do several task like telling the time, searching web pages, openning apps and I can answer your questions.")
            elif query.lower() == 'stop':
                print("Bye bye")
                say("Bye bye")
                os._exit(0)

            else:
                say(query)

        while asleep:
            print("Sleeping...")
            query = take_command()
            if query is None:
                pass
            elif query.lower() == "awake" or query.lower() == "wake up":
                asleep=False
                print("Wakeing Up")
                say("Waking up")

            elif  query.lower()=="go to sleep" or query.lower()== "sleep my assistant":
                print("I am sleeping already")
                say("I am sleeping already")

            elif query.lower() == 'stop':
                print("Bye bye")
                say("Bye bye")
                os._exit(0)